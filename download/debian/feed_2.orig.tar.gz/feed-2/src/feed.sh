#!/bin/sh

FEED_DATABASE=${HOME}/.feed
export FEED_DATABASE
